import {
  renderTracks,
  renderAlbums,
  renderStats,
  showView,
  showLoading,
  hideLoading,
  showError,
  renderPlaylists,
} from "./ui.js";

import {
  saveTracks,   getTracks,
  saveAlbums,   getAlbums,
  savePlaylists, getPlaylists as getCachedPlaylists,
  saveTokens,   getAccessToken,
  getRefreshToken, isTokenExpired,
  saveVerifier, getVerifier,
  clearAuth,
} from "./storage.js";

/* =======================
   CONFIG
======================= */

const CLIENT_ID = "5a77f12758da4c94a068385d5745ea5a";
const REDIRECT  = "http://127.0.0.1:5173/";
const SCOPES    = [
  "user-read-private",
  "user-read-email",
  "user-library-read",
  "playlist-read-private",
].join(" ");

/* =======================
   MODULE STATE
======================= */

let allTracks    = [];
let allAlbums    = [];
let allPlaylists = [];

/* =======================
   ENTRY POINT
======================= */

init();

async function init() {
  wireNav();
  wireSearch();
  wireSortControls();

  document.getElementById("spotify-button")?.addEventListener("click", login);

  const code = new URLSearchParams(window.location.search).get("code");

  if (code) {
    try {
      showLoading("Connecting to Spotify…");
      const tokenData = await fetchAccessToken(code);
      saveTokens(tokenData);
      window.history.replaceState({}, document.title, "/");
    } catch (err) {
      showError("Login failed — please try again.");
      console.error(err);
      hideLoading();
      return;
    }
  }

  let token = getAccessToken();
  if (!token) { hideLoading(); return; }

  if (isTokenExpired()) {
    token = await tryRefreshToken();
    if (!token) { hideLoading(); return; }
  }

  // Load cached data instantly
  const cachedTracks    = getTracks();
  const cachedAlbums    = getAlbums();
  const cachedPlaylists = getCachedPlaylists();

  if (cachedTracks) {
    allTracks = cachedTracks;
    renderTracks(allTracks);
    showView("library");
  }

  if (cachedAlbums) {
    allAlbums = cachedAlbums;
    renderAlbums(allAlbums);
  }

  if (cachedPlaylists) {
    allPlaylists = cachedPlaylists;
    renderPlaylists(allPlaylists);
  }

  // Fetch fresh data from Spotify
  try {
    showLoading("Syncing your Spotify library…");

    const [tracks, albums, playlists] = await Promise.all([
      getFullLibrary(token),
      getSavedAlbums(token),
      fetchUserPlaylists(token),  // ✅ now defined at top level below
    ]);

    allTracks    = tracks.map(trimTrack);
    allAlbums    = albums.map(trimAlbum);
    allPlaylists = playlists;

    saveTracks(allTracks);
    saveAlbums(allAlbums);
    savePlaylists(allPlaylists);

    renderTracks(allTracks);
    renderAlbums(allAlbums);
    renderPlaylists(allPlaylists);
    renderStats(allTracks, allAlbums);
    showView("library");

    hideLoading();
  } catch (err) {
    hideLoading();

    if (err.status === 401) {
      const newToken = await tryRefreshToken();
      if (!newToken) {
        showError("Session expired. Please log in again.");
        clearAuth();
        return;
      }
      window.location.reload();
      return;
    }

    showError("Failed to load library. Console error?");
    console.error("Sync error:", err);
  }
}


function trimTrack(track) {
  return {
    id:           track.id,
    name:         track.name,
    duration_ms:  track.duration_ms,
    popularity:   track.popularity,
    external_urls: { spotify: track.external_urls?.spotify },
    artists: track.artists?.map(a => ({ id: a.id, name: a.name })),
    album: {
      name:         track.album?.name,
      release_date: track.album?.release_date,
      images:       track.album?.images,
    },
  };
}

function trimAlbum(album) {
  return {
    id:           album.id,
    name:         album.name,
    release_date: album.release_date,
    total_tracks: album.total_tracks,
    album_type:   album.album_type,
    external_urls: { spotify: album.external_urls?.spotify },
    artists: album.artists?.map(a => ({ id: a.id, name: a.name })),
    images:  album.images,
  };
}


/* =======================
   FULL TRACK LIBRARY
======================= */

async function getFullLibrary(token) {
  const savedRaw = await fetchAll(token, "https://api.spotify.com/v1/me/tracks");
  const liked    = savedRaw.map(item => item.track).filter(Boolean);

  const playlists = await fetchAll(token, "https://api.spotify.com/v1/me/playlists");

  // ✅ Fetch 5 playlists at a time instead of one by one
  const BATCH = 5;
  let playlistTracks = [];

  for (let i = 0; i < playlists.length; i += BATCH) {
    const batch   = playlists.slice(i, i + BATCH);
    const results = await Promise.all(
      batch.map(async pl => {
        const raw = await fetchAll(token, `https://api.spotify.com/v1/playlists/${pl.id}/tracks`);
        return raw.map(item => item.track).filter(Boolean);
      })
    );
    playlistTracks = playlistTracks.concat(results.flat());
  }

  return dedupe([...liked, ...playlistTracks]);
}

/* =======================
   USER PLAYLISTS
======================= */

async function fetchUserPlaylists(token) {   // ✅ top-level — visible everywhere
  return fetchAll(token, "https://api.spotify.com/v1/me/playlists");
}

/* =======================
   SAVED ALBUMS
======================= */

async function getSavedAlbums(token) {
  const raw = await fetchAll(token, "https://api.spotify.com/v1/me/albums");
  return raw.map(item => item.album).filter(Boolean);
}

/* =======================
   PAGINATION
======================= */

async function fetchAll(token, baseUrl) {
  let results = [];
  let url     = `${baseUrl}${baseUrl.includes("?") ? "&" : "?"}limit=50`;

  while (url) {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      const err  = new Error(`Spotify API error: ${res.status} ${res.statusText}`);
      err.status = res.status;
      throw err;
    }

    const data = await res.json();
    results    = results.concat(data.items || []);
    url        = data.next || null;
  }

  return results;
}

/* =======================
   DEDUPLICATION
======================= */

function dedupe(tracks) {
  const seen = new Set();

  return tracks.filter(track => {
    if (!track?.id || seen.has(track.id)) return false;
    seen.add(track.id);
    return true;
  });
}

/* =======================
   SEARCH
======================= */

function wireSearch() {
  document.getElementById("search")?.addEventListener("input", e => {
    const q       = e.target.value.trim().toLowerCase();
    const results = q ? searchTracks(allTracks, q) : allTracks;
    renderTracks(results);
  });
}

function searchTracks(tracks, q) {
  return tracks.filter(track =>
    track.name?.toLowerCase().includes(q) ||
    track.artists?.some(a => a.name.toLowerCase().includes(q)) ||
    track.album?.name?.toLowerCase().includes(q)
  );
}

/* =======================
   SORT CONTROLS
======================= */

function wireSortControls() {
  ["sortField", "sortOrder"].forEach(id => {
    document.getElementById(id)?.addEventListener("change", () => {
      const q = document.getElementById("search")?.value.trim().toLowerCase() || "";
      renderTracks(q ? searchTracks(allTracks, q) : allTracks);
    });
  });

  ["albumSortField", "albumSortOrder"].forEach(id => {
    document.getElementById(id)?.addEventListener("change", () => {
      renderAlbums(allAlbums);
    });
  });
}

/* =======================
   NAV
======================= */

function wireNav() {
  document.querySelectorAll("[data-view]").forEach(link => {
    link.addEventListener("click", e => {
      e.preventDefault();
      showView(link.dataset.view);
    });
  });

  document.getElementById("home")?.addEventListener("click", e => {
    e.preventDefault();
    document.getElementById("banner")?.scrollIntoView({ behavior: "smooth" });
  });
}

/* =======================
   AUTH — PKCE LOGIN
======================= */

async function login() {
  const verifier  = generateVerifier(128);
  const challenge = await generateChallenge(verifier);

  saveVerifier(verifier);

  const params = new URLSearchParams({
    client_id:             CLIENT_ID,
    response_type:         "code",
    redirect_uri:          REDIRECT,
    scope:                 SCOPES,
    code_challenge_method: "S256",
    code_challenge:        challenge,
  });

  window.location = `https://accounts.spotify.com/authorize?${params}`;
}

async function fetchAccessToken(code) {
  const body = new URLSearchParams({
    client_id:     CLIENT_ID,
    grant_type:    "authorization_code",
    code,
    redirect_uri:  REDIRECT,
    code_verifier: getVerifier(),
  });

  const res = await fetch("https://accounts.spotify.com/api/token", {
    method:  "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });

  if (!res.ok) throw new Error("Token exchange failed");
  return res.json();
}

/* =======================
   TOKEN REFRESH
======================= */

async function tryRefreshToken() {
  const refreshToken = getRefreshToken();
  if (!refreshToken) {
    clearAuth();
    showError("Session expired. Please log in again.");
    return null;
  }

  try {
    const body = new URLSearchParams({
      client_id:     CLIENT_ID,
      grant_type:    "refresh_token",
      refresh_token: refreshToken,
    });

    const res = await fetch("https://accounts.spotify.com/api/token", {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });

    if (!res.ok) throw new Error("Refresh failed");

    const data = await res.json();
    saveTokens(data);
    return data.access_token;
  } catch (err) {
    console.error("Token refresh error:", err);
    clearAuth();
    showError("Session expired. Please log in again.");
    return null;
  }
}

/* =======================
   PKCE HELPERS
======================= */

function generateVerifier(length) {
  const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  return Array.from({ length }, () =>
    chars[Math.floor(Math.random() * chars.length)]
  ).join("");
}

async function generateChallenge(verifier) {
  const data   = new TextEncoder().encode(verifier);
  const digest = await crypto.subtle.digest("SHA-256", data);

  return btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}