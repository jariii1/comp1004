/* =======================
   VIEW SWITCHING
======================= */

export function showView(viewId) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.getElementById(viewId)?.classList.add("active");

  // Sync active nav link
  document.querySelectorAll("[data-view]").forEach(link => {
    link.classList.toggle("active", link.dataset.view === viewId);
  });
}

/* =======================
   LOADING STATE
======================= */

export function showLoading(message = "Loading your music…") {
  const el = document.getElementById("loadingBanner");
  if (!el) return;
  el.textContent = message;
  el.classList.remove("hidden");
}

export function hideLoading() {
  document.getElementById("loadingBanner")?.classList.add("hidden");
}

export function showError(message) {
  const el = document.getElementById("errorBanner");
  if (!el) return;
  el.textContent = message;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 5000);
}

/* =======================
   RENDER TRACKS
======================= */

export function renderTracks(tracks) {
  const list = document.getElementById("trackList");
  if (!list) return;

  const countEl = document.getElementById("trackCount");
  if (countEl) countEl.textContent = `${tracks.length} tracks`;

  const sortField = document.getElementById("sortField")?.value || "artist";
  const sortOrder = document.getElementById("sortOrder")?.value  || "asc";
  const sorted    = sortTracks([...tracks], sortField, sortOrder);

  if (sorted.length === 0) {
    list.innerHTML = `<li class="empty-state">No tracks found.</li>`;
    return;
  }

  list.innerHTML = sorted.map(track => {
    const artists   = track.artists?.map(a => a.name).join(", ") || "—";
    const album     = track.album?.name || "—";
    const year      = track.album?.release_date?.slice(0, 4) || "—";
    const duration  = formatDuration(track.duration_ms);
    const thumb     = track.album?.images?.[2]?.url || "";
    const pop       = track.popularity != null ? track.popularity : "—";
    const popBar    = track.popularity != null
      ? `<div class="pop-bar"><div class="pop-fill" style="width:${track.popularity}%"></div></div>`
      : "";
    const spotifyUrl = track.external_urls?.spotify || "#";

    return `
      <li class="track-item">
        ${thumb
          ? `<img src="${thumb}" class="track-thumb" alt="${escHtml(track.name)}">`
          : `<div class="track-thumb track-thumb--placeholder"></div>`}
        <div class="track-info">
          <a class="track-title" href="${spotifyUrl}" target="_blank" rel="noopener">
            ${escHtml(track.name)}
          </a>
          <span class="track-artist">${escHtml(artists)}</span>
          <span class="track-album">${escHtml(album)}</span>
        </div>
        <div class="track-meta">
          <span class="meta-pill">${duration}</span>
          <span class="meta-pill">${year}</span>
          <div class="pop-wrapper" title="Spotify Popularity (0–100, global metric – not your personal play count)">
            <span class="pop-label">Pop</span>
            <span class="pop-value">${pop}</span>
            ${popBar}
          </div>
        </div>
      </li>`;
  }).join("");
}

/* =======================
   RENDER ALBUMS
======================= */

export function renderAlbums(albums) {
  const list = document.getElementById("albumList");
  if (!list) return;

  const countEl = document.getElementById("albumCount");
  if (countEl) countEl.textContent = `${albums.length} albums`;

  const sortField = document.getElementById("albumSortField")?.value || "artist";
  const sortOrder = document.getElementById("albumSortOrder")?.value  || "asc";
  const sorted    = sortAlbums([...albums], sortField, sortOrder);

  if (sorted.length === 0) {
    list.innerHTML = `<li class="empty-state">No albums found.</li>`;
    return;
  }

  list.innerHTML = sorted.map(album => {
    const artists  = album.artists?.map(a => a.name).join(", ") || "—";
    const year     = album.release_date?.slice(0, 4) || "—";
    const thumb    = album.images?.[1]?.url || album.images?.[0]?.url || "";
    const spotifyUrl = album.external_urls?.spotify || "#";

    return `
      <li class="album-item">
        ${thumb
          ? `<img src="${thumb}" class="album-thumb" alt="${escHtml(album.name)}">`
          : `<div class="album-thumb album-thumb--placeholder"></div>`}
        <div class="album-info">
          <a class="album-title" href="${spotifyUrl}" target="_blank" rel="noopener">
            ${escHtml(album.name)}
          </a>
          <span class="album-artist">${escHtml(artists)}</span>
          <div class="album-meta">
            <span class="meta-pill">${year}</span>
            <span class="meta-pill">${album.total_tracks} tracks</span>
            <span class="meta-pill">${album.album_type || ""}</span>
          </div>
        </div>
      </li>`;
  }).join("");
}


/* =======================
   RENDER Playlists
======================= */


export function renderPlaylists(playlists) {
  const list = document.getElementById("playlistList");
  if (!list) return;

  if (playlists.length === 0) {
    list.innerHTML = `<li class="empty-state">No playlists found.</li>`;
    return;
  }

  list.innerHTML = playlists.map(pl => {
    const thumb      = pl.images?.[0]?.url || "";
    const trackCount = pl.tracks?.total ?? "—";
    const spotifyUrl = pl.external_urls?.spotify || "#";

    return `
      <li class="track-item">
        ${thumb
          ? `<img src="${thumb}" class="track-thumb" alt="${escHtml(pl.name)}">`
          : `<div class="track-thumb track-thumb--placeholder"></div>`}
        <div class="track-info">
          <a class="track-title" href="${spotifyUrl}" target="_blank" rel="noopener">
            ${escHtml(pl.name)}
          </a>
          <span class="track-artist">${escHtml(pl.owner?.display_name || "")}</span>
        </div>
        <div class="track-meta">
          <span class="meta-pill">${trackCount} tracks</span>
        </div>
      </li>`;
  }).join("");
}

/* =======================
   RENDER STATS
======================= */

export function renderStats(tracks, albums) {
  const el = document.getElementById("statsPanel");
  if (!el) return;

  const totalArtists = new Set(
    tracks.flatMap(t => t.artists?.map(a => a.id) || [])
  ).size;

  const avgPop = tracks.length
    ? Math.round(tracks.reduce((s, t) => s + (t.popularity || 0), 0) / tracks.length)
    : 0;

  const topArtists = getTopArtists(tracks).slice(0, 5);

  el.innerHTML = `
    <div class="stat-grid">
      <div class="stat-card">
        <span class="stat-num">${tracks.length}</span>
        <span class="stat-label">Tracks</span>
      </div>
      <div class="stat-card">
        <span class="stat-num">${totalArtists}</span>
        <span class="stat-label">Artists</span>
      </div>
      <div class="stat-card">
        <span class="stat-num">${albums.length}</span>
        <span class="stat-label">Albums</span>
      </div>
      <div class="stat-card">
        <span class="stat-num">${avgPop}</span>
        <span class="stat-label">Avg Popularity</span>
      </div>
    </div>
    <div class="top-artists">
      <h4>Top Artists in Your Library</h4>
      <ol>
        ${topArtists.map(([name, count]) =>
          `<li><span class="artist-name">${escHtml(name)}</span><span class="meta-pill">${count} tracks</span></li>`
        ).join("")}
      </ol>
    </div>`;
}

/* =======================
   SORT HELPERS
======================= */

function sortTracks(tracks, field, order) {
  const dir = order === "asc" ? 1 : -1;

  return tracks.sort((a, b) => {
    switch (field) {
      case "artist":
        return dir * (a.artists?.[0]?.name || "").localeCompare(b.artists?.[0]?.name || "");
      case "title":
        return dir * (a.name || "").localeCompare(b.name || "");
      case "popularity":
        return dir * ((a.popularity ?? -1) - (b.popularity ?? -1));
      case "duration":
        return dir * ((a.duration_ms ?? 0) - (b.duration_ms ?? 0));
      case "year":
        return dir * (a.album?.release_date || "").localeCompare(b.album?.release_date || "");
      default:
        return 0;
    }
  });
}

function sortAlbums(albums, field, order) {
  const dir = order === "asc" ? 1 : -1;

  return albums.sort((a, b) => {
    switch (field) {
      case "artist":
        return dir * (a.artists?.[0]?.name || "").localeCompare(b.artists?.[0]?.name || "");
      case "title":
        return dir * (a.name || "").localeCompare(b.name || "");
      case "year":
        return dir * (a.release_date || "").localeCompare(b.release_date || "");
      default:
        return 0;
    }
  });
}

function getTopArtists(tracks) {
  const counts = {};
  tracks.forEach(track => {
    track.artists?.forEach(artist => {
      counts[artist.name] = (counts[artist.name] || 0) + 1;
    });
  });

  return Object.entries(counts).sort((a, b) => b[1] - a[1]);
}

/* =======================
   UTILITIES
======================= */

function formatDuration(ms) {
  if (!ms) return "—";
  const min = Math.floor(ms / 60_000);
  const sec = Math.floor((ms % 60_000) / 1_000).toString().padStart(2, "0");
  return `${min}:${sec}`;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}