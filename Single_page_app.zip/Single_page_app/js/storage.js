/* =======================
   STORAGE KEYS
======================= */

const KEYS = {
  tracks:       "ps_tracks",
  albums:       "ps_albums",
  playlists:    "ps_playlists",
  token:        "access_token",
  refreshToken: "refresh_token",
  verifier:     "verifier",
  expiry:       "token_expiry",
};

/* =======================
   TRACKS
======================= */

export function saveTracks(tracks) {
  localStorage.setItem(KEYS.tracks, JSON.stringify(tracks));
}

export function getTracks() {
  const raw = localStorage.getItem(KEYS.tracks);
  return raw ? JSON.parse(raw) : null;
}

/* =======================
   ALBUMS
======================= */

export function saveAlbums(albums) {
  localStorage.setItem(KEYS.albums, JSON.stringify(albums));
}

export function getAlbums() {
  const raw = localStorage.getItem(KEYS.albums);
  return raw ? JSON.parse(raw) : null;
}

/* =======================
   PLAYLISTS
======================= */

export function savePlaylists(playlists) {
  localStorage.setItem(KEYS.playlists, JSON.stringify(playlists));
}

export function getPlaylists() {
  const raw = localStorage.getItem(KEYS.playlists);
  return raw ? JSON.parse(raw) : null;
}

/* =======================
   AUTH TOKENS
======================= */

export function saveTokens({ access_token, refresh_token, expires_in }) {
  localStorage.setItem(KEYS.token, access_token);
  if (refresh_token) localStorage.setItem(KEYS.refreshToken, refresh_token);
  if (expires_in) {
    const expiry = Date.now() + expires_in * 1000;
    localStorage.setItem(KEYS.expiry, expiry);
  }
}

export function getAccessToken() {
  return localStorage.getItem(KEYS.token);
}

export function getRefreshToken() {
  return localStorage.getItem(KEYS.refreshToken);
}

export function isTokenExpired() {
  const expiry = localStorage.getItem(KEYS.expiry);
  if (!expiry) return false;
  return Date.now() > Number(expiry) - 60_000; // 1 min buffer
}

export function getVerifier() {
  return localStorage.getItem(KEYS.verifier);
}

export function saveVerifier(v) {
  localStorage.setItem(KEYS.verifier, v);
}

export function clearAuth() {
  [KEYS.token, KEYS.refreshToken, KEYS.verifier, KEYS.expiry].forEach(k =>
    localStorage.removeItem(k)
  );
}